USE LeoTurfTest

SELECT * FROM LTApuestas
SELECT * FROM LTCaballos
SELECT * FROM LTCaballosCarreras
SELECT * FROM LTCarreras
SELECT * FROM LTHipodromos