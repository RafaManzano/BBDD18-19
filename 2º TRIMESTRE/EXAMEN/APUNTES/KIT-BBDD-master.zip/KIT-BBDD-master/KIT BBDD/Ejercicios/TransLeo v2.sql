CREATE DATABASE TransLeo
GO
USE TransLeo
GO

CREATE TABLE Clientes(
	
)

CREATE TABLE Paquetes(
)

CREATE TABLE Centros(
)

CREATE TABLE Vehiculos(
)